-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : vacuumcup
-- 
-- Part : #1
-- Date : 2019-07-23 15:21:48
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `admin`
-- -----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `password` varchar(32) COLLATE utf8_bin DEFAULT '' COMMENT '密码',
  `portrait` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '头像',
  `loginnum` int(11) DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '真实姓名',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  `groupid` int(11) DEFAULT '1' COMMENT '用户角色id',
  `token` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `admin`
-- -----------------------------
INSERT INTO `admin` VALUES ('1', 'admin', '218dbb225911693af03a713581a7227f', '20181122\\admin.jpeg', '1187', '127.0.0.1', '1563864231', 'admin', '1', '1', '1ac2fc424c64cdf80db98a246f439287');
INSERT INTO `admin` VALUES ('39', 'gjg', '218dbb225911693af03a713581a7227f', '', '0', '', '0', '飒飒', '1', '25', '');

-- -----------------------------
-- Table structure for `auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `org_num` int(11) NOT NULL DEFAULT '0' COMMENT '组织编号',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text,
  `create_time` int(11) NOT NULL DEFAULT '0',
  `update_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `auth_group`
-- -----------------------------
INSERT INTO `auth_group` VALUES ('1', '超级管理员', '0', '1', '', '1561010232', '1561010232');
INSERT INTO `auth_group` VALUES ('25', '阿萨大大', '0', '1', '', '1563866342', '1563866342');

-- -----------------------------
-- Table structure for `auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `auth_group_access`;
CREATE TABLE `auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `auth_group_access`
-- -----------------------------
INSERT INTO `auth_group_access` VALUES ('1', '1');
INSERT INTO `auth_group_access` VALUES ('39', '25');

-- -----------------------------
-- Table structure for `auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE `auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL DEFAULT '' COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=314 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `auth_rule`
-- -----------------------------
INSERT INTO `auth_rule` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '20', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('2', 'admin/admin/index', '用户管理', '1', '1', '', '', '1', '1', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('3', 'admin/role/index', '角色管理', '1', '1', '', '', '1', '2', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('4', 'admin/menu/index', '菜单管理', '1', '1', '', '', '1', '3', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('5', '#', '数据库管理', '1', '1', 'fa fa-database', '', '0', '19', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('6', 'admin/data/index', '数据库备份', '1', '1', '', '', '5', '1', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('7', 'admin/data/optimize', '优化表', '1', '1', '', '', '6', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('8', 'admin/data/repair', '修复表', '1', '1', '', '', '6', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('9', 'admin/admin/adminAdd', '添加用户', '1', '1', '', '', '2', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('10', 'admin/admin/adminEdit', '编辑用户', '1', '1', '', '', '2', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('11', 'admin/admin/adminDel', '删除用户', '1', '1', '', '', '2', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('12', 'admin/admin/user_state', '用户状态', '1', '1', '', '', '2', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('13', '#', '日志管理', '1', '1', 'fa fa-tasks', '', '0', '18', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('14', 'admin/log/operate_log', '行为日志', '1', '1', '', '', '13', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('22', 'admin/log/del_log', '删除日志', '1', '1', '', '', '14', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('27', 'admin/data/import', '数据库还原', '1', '1', '', '', '5', '2', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('28', 'admin/data/revert', '还原', '1', '1', '', '', '27', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('29', 'admin/data/del', '删除', '1', '1', '', '', '27', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('30', 'admin/role/roleAdd', '添加角色', '1', '1', '', '', '3', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('31', 'admin/role/roleEdit', '编辑角色', '1', '1', '', '', '3', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('32', 'admin/role/roleDel', '删除角色', '1', '1', '', '', '3', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('33', 'admin/role/role_state', '角色状态', '1', '1', '', '', '3', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('34', 'admin/role/giveAccess', '权限分配', '1', '1', '', '', '3', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('35', 'admin/menu/add_rule', '添加菜单', '1', '1', '', '', '4', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('36', 'admin/menu/edit_rule', '编辑菜单', '1', '1', '', '', '4', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('37', 'admin/menu/del_rule', '删除菜单', '1', '1', '', '', '4', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('38', 'admin/menu/rule_state', '菜单状态', '1', '1', '', '', '4', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('39', 'admin/menu/ruleorder', '菜单排序', '1', '1', '', '', '4', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('61', 'admin/config/index', '配置管理', '1', '1', '', '', '1', '4', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('62', 'admin/config/index', '配置列表', '1', '1', '', '', '61', '50', '1556269085', '1556269105');
INSERT INTO `auth_rule` VALUES ('63', 'admin/config/save', '保存配置', '1', '1', '', '', '61', '50', '1556269085', '1556269105');

-- -----------------------------
-- Table structure for `config`
-- -----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `config`
-- -----------------------------
INSERT INTO `config` VALUES ('1', 'web_site_title', '项目管理系统');
INSERT INTO `config` VALUES ('2', 'web_site_description', '项目管理系统');
INSERT INTO `config` VALUES ('3', 'web_site_keyword', '项目管理系统');
INSERT INTO `config` VALUES ('4', 'web_site_icp', '粤ICP备15002349号-1');
INSERT INTO `config` VALUES ('5', 'web_site_cnzz', '');
INSERT INTO `config` VALUES ('6', 'web_site_copy', 'Copyright © 2019 项目管理系统 All rights reserved.');
INSERT INTO `config` VALUES ('7', 'web_site_close', '1');
INSERT INTO `config` VALUES ('8', 'list_rows', '5');
INSERT INTO `config` VALUES ('9', 'admin_allow_ip', '');
INSERT INTO `config` VALUES ('10', 'alisms_appkey', 'UejF485jyYuyTxcd');
INSERT INTO `config` VALUES ('11', 'alisms_appsecret', 'uLSBt24uFZILZ0GCw5eewwginQrX6U');
INSERT INTO `config` VALUES ('12', 'alisms_signname', '注册验证');
INSERT INTO `config` VALUES ('13', 'words_is_audit', '0');
INSERT INTO `config` VALUES ('14', 'comment_is_audit', '0');
INSERT INTO `config` VALUES ('15', 'device_is_audit', '0');
INSERT INTO `config` VALUES ('16', 'wechat_appkey', '123');
INSERT INTO `config` VALUES ('17', 'wechat_appsecret', '123');

-- -----------------------------
-- Table structure for `log`
-- -----------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `title` varchar(225) NOT NULL DEFAULT '' COMMENT '标题',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `log`
-- -----------------------------
INSERT INTO `log` VALUES ('1', '1', 'admin', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1561357420');
INSERT INTO `log` VALUES ('2', '1', 'admin', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1561357904');
INSERT INTO `log` VALUES ('4', '1', 'admin', '添加后台用户', '用户【gjg】添加成功', '127.0.0.1', '', '1563866371');

-- -----------------------------
-- Table structure for `user`
-- -----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(128) NOT NULL COMMENT '用户名',
  `nick` varchar(128) NOT NULL COMMENT '昵称',
  `password` varchar(128) NOT NULL COMMENT '密码',
  `sex` tinyint(2) NOT NULL COMMENT '性别   0：女  1：男',
  `moblie` varchar(32) NOT NULL COMMENT '手机',
  `email` varchar(64) DEFAULT NULL COMMENT '邮箱',
  `token` varchar(32) DEFAULT NULL,
  `create_time` int(12) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `user`
-- -----------------------------
INSERT INTO `user` VALUES ('1', 'user123', '测试', '123456', '1', '15674125893', '254878278@qq.com', '', '0');
